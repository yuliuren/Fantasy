namespace Fantasy
{
	public static partial class InnerBsonOpcode
	{
	}
}
