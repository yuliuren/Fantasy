namespace Fantasy
{
	public static partial class InnerOpcode
	{
		 public const int TestServerRequest = 130001001;
		 public const int TestServerResponse = 170001001;
		 public const int TestServerMessage = 120001001;
	}
}
