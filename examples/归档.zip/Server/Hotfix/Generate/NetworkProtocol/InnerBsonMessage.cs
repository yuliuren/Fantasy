using ProtoBuf;
using System.Collections.Generic;

#pragma warning disable CS8618

namespace Fantasy
{	
}
