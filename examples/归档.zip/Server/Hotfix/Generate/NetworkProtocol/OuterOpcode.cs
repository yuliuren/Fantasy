namespace Fantasy
{
	public static partial class OuterOpcode
	{
		 public const int C2A_TestRequest = 110000001;
		 public const int A2C_TestResponse = 160000001;
	}
}
