﻿// See https://aka.ms/new-console-template for more information
using Fantasy;
await Entry.Start(AssemblyHelper.LoadModelAssembly(), AssemblyHelper.LoadHotfixAssembly());